#!/usr/bin/env python
'''sharepathway
'''
from sharepathway.run import Run

VERSION = '0.1.1'