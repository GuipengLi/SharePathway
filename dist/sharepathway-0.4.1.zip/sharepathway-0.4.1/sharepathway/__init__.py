#!/usr/bin/env python
'''sharepathway
'''
from .run import Run

VERSION = '0.4.1'
